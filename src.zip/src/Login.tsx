import { VStack, Image, Text, Box, Link } from 'native-base';
import Logo from './assets/Logo.png';
import { TouchableOpacity } from 'react-native';
import { Botao } from './componentes/Botao';
import { EntradaTexto } from './componentes/EntradaTexto';
import { Titulo } from './componentes/titulo';

export default function Login({ navigation }) {
    return (
        <VStack flex={1} alignItems='center' justifyContent="center" p={5}>
            <Image source={Logo} alt='Login'></Image>
            <Titulo>
                Faça Login em sua conta
            </Titulo>
            <Box>
                <EntradaTexto placeholder='Insira seu email' label='Email'></EntradaTexto>
                <EntradaTexto placeholder='Insira sua senha' label='Senha' secureTextEntry={true}></EntradaTexto>
            </Box>
            <Botao onPress={() => navigation.navigate('Tabs')}>
                Entrar
            </Botao>
            <Link href='https://google.com.br' mt={2}>Esqueceu sua senha?</Link>
            <Box w={'100%'} flexDirection={'row'} justifyContent={'center'} mt={2}>
                <Text>Ainda não tem cadastro?</Text>
                <TouchableOpacity onPress={() => navigation.navigate('Cadastro')}>
                    <Text color={'blue.500'}>Faça seu cadastro</Text>
                </TouchableOpacity>
            </Box>
        </VStack>
    );
}