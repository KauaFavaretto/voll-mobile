import { VStack, Text } from "native-base";

export default function Principal() {
    return (
        <VStack>
            <Text>Principal</Text>
        </VStack>
    )
}