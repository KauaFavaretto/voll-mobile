import { VStack, Text, ScrollView, Avatar, Divider } from "native-base";
import { Titulo } from "../componentes/titulo";

export default function Perfil() {
    return (
        <ScrollView flex={1}>
            <VStack flex={1} alignItems={'Center'} p={5}>
                <Titulo color={'blue.500'}>Meu Perfil</Titulo>
                <Avatar
                    source={{
                        uri: 'https://avatars.githubusercontent.com/u/105598408?v=4'
                    }}
                    mt={5}
                    size={'xl'}
                />
                <Titulo color={'blue.500'}>Informações Pessoais</Titulo>
                <Titulo fontSize={'lg'}>Kauã Favaretto</Titulo>
                <Titulo>13/03/2005</Titulo>
                <Titulo>Valentim Gentil - SP</Titulo>

                <Divider mt={5} />

                <Titulo>Histórico Médico</Titulo>
                <Text>Bronquite</Text>
                <Text>Sinusite</Text>
            </VStack>
        </ScrollView>
    )
}