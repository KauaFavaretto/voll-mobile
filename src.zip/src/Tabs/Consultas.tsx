import { VStack, Text } from "native-base";
import { CardConsulta } from "../componentes/CardConsulta";

export default function Consultas() {
    return (
        <VStack p={5}>
            <Text>Consultas</Text>
            <CardConsulta
                nome='Dr. Letícia'
                especialidade="Dentista"
                foto="https://avatars.githubusercontent.com/u/105598408?v=4"
                data="20/06/2024"
                foiAgendado
                foiAtendido
            />
        </VStack>
    )
}