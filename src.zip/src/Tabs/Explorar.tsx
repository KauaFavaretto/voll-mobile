import { VStack, Text, Input, ScrollView, Box } from "native-base";
import { CardConsulta } from "../componentes/CardConsulta";
import { Botao } from "../componentes/Botao";
import { Titulo } from "../componentes/titulo";
import { EntradaTexto } from "../componentes/EntradaTexto";

export default function Consultas() {
    return (
        <ScrollView flex={1} bg={"white"}>
            <VStack flex={1} alignItems={'flex-start'} justifyContent={'flex-start'} p={5}>
                <Box w={'100%'} borderRadius={'lg'} p={3} shadow={1} borderBottomRightRadius={'md'}>
                    <EntradaTexto
                        placeholder="Digite a especialidade"
                    />
                    <EntradaTexto
                        placeholder="Digite sua localização"
                    />
                    <Botao mt={3} mb={3}>Buscar</Botao>
                </Box>

                <Titulo color={'blue.500'} alignSelf={'center'} mb={4}>Resultado da busca</Titulo>
                {[1, 2, 3].map((_, index) => (
                    <VStack flex={1} w={'100%'} alignItems={'flex-start'} bgColor={'white'} mb={5} key={index}>
                        <CardConsulta
                            especialidade="Cardiologista"
                            foto="https://avatars.githubusercontent.com/u/105598408?v=4"
                            nome="Dr. Kauã Favaretto"
                        />
                    </VStack>
                ))}

            </VStack>

        </ScrollView>
    )
}